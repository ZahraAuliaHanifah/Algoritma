import java.util.Scanner;

public class Kuadrat {     
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan bilangan: ");
        int bilangan = scanner.nextInt();
        
        int hasil = 0;
        
        // Menggunakan iterasi untuk menghitung pangkat dua
        for (int i = 0; i < bilangan; i++) {
            hasil += bilangan;
        }
        
        // Menampilkan hasil
        System.out.println("Hasil pangkat dua dari " + bilangan + " adalah: " + hasil);
        
        scanner.close();
    }
}
